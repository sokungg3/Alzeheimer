class MyConstant {
  String domain = 'http://restaurant2019.com';

  MyConstant();
}