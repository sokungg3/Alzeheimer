package com.example.Alzeheimer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
